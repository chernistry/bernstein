# Compliance pack — Acme Bank

Demo bundle for the fintech lineage scenario.
Window: 2026-01-01 .. 2026-02-14
Entries: 30

Verify with:  bernstein-verify pack expected-pack.zip
