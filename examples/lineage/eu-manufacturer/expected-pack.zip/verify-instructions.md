# Verifying this pack

1. Install the auditor CLI:    pipx install bernstein-verify
2. Run:                        bernstein-verify pack expected-pack.zip
3. Exit 0 + 'PASS' line = signatures valid, chain complete, no unresolved forks.
